import{h_ as r}from"./index-DLX4pCWG.js";var e=4;function a(o){return r(o,e)}export{a as c};
