const o=c=>{const e=document.createElement("a");e.href=c,e.click()};export{o as d};
