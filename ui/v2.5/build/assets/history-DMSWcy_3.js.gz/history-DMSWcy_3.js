function c(e,a){e.length>1?e.goBack():e.replace(a)}export{c as g};
