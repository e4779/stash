function o(e,n){return e||n||void 0}export{o as s};
