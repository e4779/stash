import{r as o}from"./index-DLX4pCWG.js";function t(){o.useEffect(()=>{window.scrollTo(0,0)},[])}export{t as u};
