#### 💥 Note: Please check your logs after migrating to this release. A log warning will be generated on startup if duplicate image checksums exist in your system. Search for the images using the logged checksums, and remove the unwanted ones.

#### 💥 Note: The system will now stop serving requests if authentication is not configured and it detects a connection from public internet. See [this link](https://github.com/stashapp/stash/wiki/Authentication-Required-When-Accessing-Stash-From-the-Internet) for details.

### ✨ New Features
* Added support for Tag hierarchies. ([#1519](https://github.com/stashapp/stash/pull/1519))
* Revamped image lightbox to support zoom, pan and various display modes. ([#1708](https://github.com/stashapp/stash/pull/1708))
* Added support for Studio aliases. ([#1660](https://github.com/stashapp/stash/pull/1660))
* Added support for querying scene scrapers using keywords. ([#1712](https://github.com/stashapp/stash/pull/1712))
* Added native support for Apple Silicon / M1 Macs. ([#1646](https://github.com/stashapp/stash/pull/1646))
* Support subpaths when serving stash via reverse proxy. ([#1719](https://github.com/stashapp/stash/pull/1719))
* Disallow access from public internet addresses when authentication is not configured. ([#1761](https://github.com/stashapp/stash/pull/1761))
* Added options to generate webp and static preview files for markers. ([#1604](https://github.com/stashapp/stash/pull/1604))
* Added sort by option for gallery rating. ([#1720](https://github.com/stashapp/stash/pull/1720))
* Added Movies to Scene bulk edit dialog. ([#1676](https://github.com/stashapp/stash/pull/1676))
* Added Movies tab to Studio and Performer pages. ([#1675](https://github.com/stashapp/stash/pull/1675))
* Support filtering Movies by Performers. ([#1675](https://github.com/stashapp/stash/pull/1675))

### 🎨 Improvements
* Optimised image thumbnail generation (optionally using `libvips`) and made optional. ([#1655](https://github.com/stashapp/stash/pull/1655))
* Improved image query performance. ([#1740](https://github.com/stashapp/stash/pull/1740), [#1750](https://github.com/stashapp/stash/pull/1750))
* Support setting metadata import/export directory from UI. ([#1782](https://github.com/stashapp/stash/pull/1782))
* Added movie count to performer and studio cards. ([#1760](https://github.com/stashapp/stash/pull/1760))
* Added date and details to Movie card, and move scene count to icon. ([#1758](https://github.com/stashapp/stash/pull/1758))
* Added date and details to Gallery card, and move image count to icon. ([#1763](https://github.com/stashapp/stash/pull/1763))
* Support scraper script logging to specific log levels. ([#1648](https://github.com/stashapp/stash/pull/1648))
* Added sv-SE language option. ([#1691](https://github.com/stashapp/stash/pull/1691))

### 🐛 Bug fixes
* Disabled float-on-scroll player on mobile devices. ([#1721](https://github.com/stashapp/stash/pull/1721))
* Fix video transcoding process starting before video is played. ([#1780](https://github.com/stashapp/stash/pull/1780))
* Fix Scene Edit Panel form layout for mobile and desktop. ([#1737](https://github.com/stashapp/stash/pull/1737))
* Don't scan zero-length files. ([#1779](https://github.com/stashapp/stash/pull/1779))
* Accept svg files in file selector for tag images. ([#1778](https://github.com/stashapp/stash/pull/1778))
* Optimised exclude filter queries. ([#1815](https://github.com/stashapp/stash/pull/1815))
* Fix video player aspect ratio shifting sometimes when clicking scene tabs. ([#1764](https://github.com/stashapp/stash/pull/1764))
* Fix criteria being incorrectly applied when clicking back button. ([#1765](https://github.com/stashapp/stash/pull/1765))
* Show first page and fix order direction not being maintained when clicking on card popover button. ([#1765](https://github.com/stashapp/stash/pull/1765))
* Fix panic in autotagger when backslash character present in tag/performer/studio name. ([#1753](https://github.com/stashapp/stash/pull/1753))
* Fix Scene Player CLS issue ([#1739](https://github.com/stashapp/stash/pull/1739))
* Fix Gallery create plugin hook not being invoked when creating Gallery from folder. ([#1731](https://github.com/stashapp/stash/pull/1731)) 
* Fix tag aliases not being matched when autotagging from the tasks page. ([#1713](https://github.com/stashapp/stash/pull/1713))
* Fix Create Marker form on small devices. ([#1718](https://github.com/stashapp/stash/pull/1718))
