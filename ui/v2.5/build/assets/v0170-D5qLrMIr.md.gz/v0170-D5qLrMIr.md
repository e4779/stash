After migrating, please run a scan on your entire library to populate missing data, and to ingest identical files which were previously ignored.

### 💥 Known issues and other changes
* Import/export schema has changed and is incompatible with the previous version.
* `Set name, date, details from embedded file metadata` scan flag is no longer supported. This functionality may be implemented as a built-in scraper in the future.

### ✨ New Features
* Added support for identical files. Identical files are assigned to the same scene/gallery/image and can be viewed in File Info. ([#2676](https://github.com/stashapp/stash/pull/2676))
* Added support for setting primary file for scenes, images and galleries. ([#2790](https://github.com/stashapp/stash/pull/2790))
* Added support for deleting secondary files from scenes, images and galleries. ([#2790](https://github.com/stashapp/stash/pull/2790))
* Added support for filtering and sorting by file count. ([#2744](https://github.com/stashapp/stash/pull/2744))
* Added description field to Tags. ([#2708](https://github.com/stashapp/stash/pull/2708))
* Added Interface option to abbreviate counts on cards and details pages. ([#2781](https://github.com/stashapp/stash/pull/2781))
* Added Interface options to include sub-studio/sub-tag content in Studio/Tag pages. ([#2832](https://github.com/stashapp/stash/pull/2832))
* Populate name from query field when creating new performer/studio/tag/gallery. ([#2701](https://github.com/stashapp/stash/pull/2701))
* Added backup location configuration setting. ([#2953](https://github.com/stashapp/stash/pull/2953))
* Allow overriding UI localisation strings. ([#2837](https://github.com/stashapp/stash/pull/2837))
* Added release notes dialog. ([#2726](https://github.com/stashapp/stash/pull/2726))

### 🎨 Improvements
* **[0.17.1]** Added Ukrainian language option.
* Object titles are now displayed as the file basename if the title is not explicitly set. The `Don't include file extension as part of the title` scan flag is no longer supported.
* Optionally show Tag card when hovering over tag badge. ([#2708](https://github.com/stashapp/stash/pull/2708))
* Show default thumbnails for scenes and images where the actual image is not found. ([#2949](https://github.com/stashapp/stash/pull/2949))
* Added unix timestamp parsing in the `parseDate` scraper post processor. ([#2817](https://github.com/stashapp/stash/pull/2817))
* Improve matching scene order in the tagger to prioritise matching phashes and durations. ([#2840](https://github.com/stashapp/stash/pull/2840)) 
* Encode reserved characters in query URLs. ([#2899](https://github.com/stashapp/stash/pull/2899))
* Moved Changelogs to Settings page. ([#2726](https://github.com/stashapp/stash/pull/2726))

### 🐛 Bug fixes
* **[0.17.2]** Fix file rename detection on case-insensitive file systems. ([#3047](https://github.com/stashapp/stash/pull/3047))
* **[0.17.2]** Fix size calculation for symlinks. ([#3046](https://github.com/stashapp/stash/pull/3046))
* **[0.17.2]** Use file base name as title if title is empty in scraper operations. ([#3040](https://github.com/stashapp/stash/pull/3040))
* **[0.17.2]** Fix error when submitting fingerprints from deleted scene. ([#3039](https://github.com/stashapp/stash/pull/3039))
* **[0.17.2]** Fix moved zip file creating duplicate galleries. ([#3036](https://github.com/stashapp/stash/pull/3036))
* **[0.17.1]** Fix Windows exporting incompatible zip files. ([#3022](https://github.com/stashapp/stash/pull/3022))
* **[0.17.1]** Fix migration error handling various NULL values. ([#3021](https://github.com/stashapp/stash/pull/3021))
* **[0.17.1]** Updated translations missed during release.
* Fix live transcoded videos hanging at end. ([#2996](https://github.com/stashapp/stash/pull/2996))
* Fix display of scene markers when title is empty. ([#2994](https://github.com/stashapp/stash/pull/2994))
* Fix tag marker count sorting. ([#2993](https://github.com/stashapp/stash/pull/2993))
* Fix studio/tag alias and caption null filtering. ([#2990](https://github.com/stashapp/stash/pull/2990))
* Fix generated file naming algorithm being set incorrectly in certain circumstances. ([#2496](https://github.com/stashapp/stash/pull/2946))
* Fix continue queue checkbox value not persisting. ([#2895](https://github.com/stashapp/stash/pull/2895))
* Fix `autostartVideoOnPlaySelected` option not applying when navigating from scene queue. ([#2896](https://github.com/stashapp/stash/pull/2896))
* Fix incorrect gallery value in Scene edit tab after navigating from scene queue. ([#2897](https://github.com/stashapp/stash/pull/2897))
* Fix https schema not being used over some https connections. ([#2900](https://github.com/stashapp/stash/pull/2900))
* Fix scene files not deleting correctly when streaming over https. ([#2900](https://github.com/stashapp/stash/pull/2900))
* Fix panic when custom performer image location is invalid. ([#2894](https://github.com/stashapp/stash/pull/2894))
