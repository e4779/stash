##### 💥 Note: The cache directory is now required if using HLS/DASH streaming. Please set the cache directory in the System Settings page.

##### 💥 Note: The image data subsystem has been reworked in this release. Existing systems will have their storage system set to `Database`, which stores all image data in the database. This can be changed in the System Settings page. 

A migration is required to change the storage system, and can be accessed from the Tasks page.

The `Database` storage system is not recommended for large libraries, as it can cause performance issues. The `Filesystem` storage system is recommended for large libraries, and is the default for new systems.

##### 💥 Note: the `generated/screenshots` jpg files are now considered legacy. These files can be migrated into the blob storage system by running the `Migrate Screenshots` task from the Tasks page. 

Once migrated, these files can be deleted. The files can be optionally deleted during the migration.

### ✨ New Features
* Added `Is Missing Cover` scene filter criterion. ([#3187](https://github.com/stashapp/stash/pull/3187))
* Added Chapters to Galleries. ([#3289](https://github.com/stashapp/stash/pull/3289))
* Added button to tagger scene cards to view scene sprite. ([#3536](https://github.com/stashapp/stash/pull/3536))
* Added hardware acceleration support (for a limited number of encoders) for transcoding. ([#3419](https://github.com/stashapp/stash/pull/3419))
* Added support for DASH streaming. ([#3275](https://github.com/stashapp/stash/pull/3275))
* Added configuration option for the maximum number of items in selector drop-downs. ([#3277](https://github.com/stashapp/stash/pull/3277))
* Added configuration option to perform generation operations sequentially after scanning a new video file. ([#3378](https://github.com/stashapp/stash/pull/3378))
* Optionally show range in generated funscript heatmaps. ([#3373](https://github.com/stashapp/stash/pull/3373))
* Show funscript heatmaps in scene player scrubber. ([#3374](https://github.com/stashapp/stash/pull/3374))
* Support customising the filename regex used for determining the gallery cover image. ([#3391](https://github.com/stashapp/stash/pull/3391))
* Added tenth-place rating precision option. ([#3343](https://github.com/stashapp/stash/pull/3343))
* Added toggleable favorite button to Performer cards. ([#3369](https://github.com/stashapp/stash/pull/3369))

### 🎨 Improvements
* Added date/time pickers for date and timestamp fields. ([#3572](https://github.com/stashapp/stash/pull/3572))
* Added folder browser to path filter UI. ([#3570](https://github.com/stashapp/stash/pull/3570))
* Include Organized flag in merge dialog. ([#3565](https://github.com/stashapp/stash/pull/3565))
* Scene cover generation is now optional during scanning, and can be generated using the Generate task. ([#3187](https://github.com/stashapp/stash/pull/3187))
* Overhauled the image blob storage system and added filesystem-based blob storage. ([#3187](https://github.com/stashapp/stash/pull/3187))
* Overhauled filtering interface to allow setting filter criteria from a single dialog. ([#3515](https://github.com/stashapp/stash/pull/3515))
* Removed upper limit on page size. ([#3544](https://github.com/stashapp/stash/pull/3544))
* Anonymise task now obfuscates Marker titles. ([#3542](https://github.com/stashapp/stash/pull/3542))
* Improved Images wall view layout and added Interface settings to adjust the layout. ([#3511](https://github.com/stashapp/stash/pull/3511))
* Added collapsible divider to Gallery, Performer, Studio and Tag pages. ([#3508](https://github.com/stashapp/stash/pull/3508), [#3514](https://github.com/stashapp/stash/pull/3514))
* Overhauled and improved HLS streaming. ([#3274](https://github.com/stashapp/stash/pull/3274))

### 🐛 Bug fixes
* **[0.20.2]** Fixed empty strings being preferred in scrape dialog. ([#3647](https://github.com/stashapp/stash/pull/3647))
* **[0.20.2]** Fixed scene covers being regenerated when video file was moved. ([#3646](https://github.com/stashapp/stash/pull/3646))
* **[0.20.1]** Fixed null values being preferred in scrape dialog. ([#3621](https://github.com/stashapp/stash/pull/3621))
* Fixed login screen not working correctly from the logout screen. ([#3555](https://github.com/stashapp/stash/pull/3555))
* Fixed incorrect stash ID being overwritten when updating performer with multiple stash-box endpoints. ([#3543](https://github.com/stashapp/stash/pull/3543)
* Fixed batch performer update overwriting incorrect stash IDs when multiple endpoints are configured. ([#3548](https://github.com/stashapp/stash/pull/3548))
* Fixed `/stream` endpoint serving directory list. ([#3541](https://github.com/stashapp/stash/pull/3541))
* Fixed error when querying with a large or unlimited page size. ([#3544](https://github.com/stashapp/stash/pull/3544))
* Fixed sprites not being displayed for scenes with numeric-only hashes. ([#3513](https://github.com/stashapp/stash/pull/3513))
* Fixed Save button being disabled when setting Tag image. ([#3509](https://github.com/stashapp/stash/pull/3509))
* Fixed incorrect performer with identical name being matched when scraping from stash-box. ([#3488](https://github.com/stashapp/stash/pull/3488))
* Fixed scene cover not being included when submitting file-less scenes to stash-box. ([#3465](https://github.com/stashapp/stash/pull/3465))
* Fixed URL not being during stash-box scrape if the Studio URL is not set. ([#3439](https://github.com/stashapp/stash/pull/3439))
* Fixed generating previews for variable frame rate videos. ([#3376](https://github.com/stashapp/stash/pull/3376))
* Fixed errors reading zip files with non-UTF8 encoding. ([#3389](https://github.com/stashapp/stash/pull/3389))
* Fixed plugins not able to access API during zip scan operations on systems with authentication enabled. ([#3433](https://github.com/stashapp/stash/pull/3433))
